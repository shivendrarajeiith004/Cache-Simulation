#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

typedef struct {
    int valid;  
    char *tag;    
    int lruCounter; 
} CacheBlock;


typedef struct {
    int totalSize;    
    int blockSize;    
    int associativity; 
    char* replacePolicy; 
    char* writePolicy;   
    int numSets;       
    CacheBlock** sets; 
} Cache;

int cacheHit = 0;
int cacheMiss = 0;

Cache* initializeCache(int totalSize, int blockSize, int associativity, char* replacePolicy, char* writePolicy) {
    Cache* cache = (Cache*)malloc(sizeof(Cache));
    cache->totalSize = totalSize;
    cache->blockSize = blockSize;
    cache->associativity = associativity;
    cache->replacePolicy = replacePolicy;
    cache->writePolicy = writePolicy;

    
    if (associativity == 1) {
        
        cache->numSets = totalSize / blockSize;
    } else if (associativity == 0) {
        
        cache->numSets = 1;
    } else {
        
        cache->numSets = totalSize / (blockSize * associativity);
    }

    
    cache->sets = (CacheBlock**)malloc(cache->numSets * sizeof(CacheBlock*));
    for (int i = 0; i < cache->numSets; i++) {
        cache->sets[i] = (CacheBlock*)malloc(associativity * sizeof(CacheBlock));
        for (int j = 0; j < associativity; j++) {
            cache->sets[i][j].valid = 0;
            
            cache->sets[i][j].lruCounter = 0;
            cache->sets[i][j].tag = (char *)malloc(1024*sizeof(char));
            cache->sets[i][j].tag[1023] = '\0';
        }
    }

    return cache;
}


char *binaryConversion(char hex) {
    char *hexReturn = (char *)malloc(5 * sizeof(char));
    switch (hex) {
        
        case '0':
            strcpy(hexReturn, "0000");
            break;
        case '1':
            strcpy(hexReturn, "0001");
            break;
        case '2':
            strcpy(hexReturn, "0010");
            break;
        case '3':
            strcpy(hexReturn, "0011");
            break;
        case '4':
            strcpy(hexReturn, "0100");
            break;
        case '5':
            strcpy(hexReturn, "0101");
            break;
        case '6':
            strcpy(hexReturn, "0110");
            break;
        case '7':
            strcpy(hexReturn, "0111");
            break;
        case '8':
            strcpy(hexReturn, "1000");
            break;
        case '9':
            strcpy(hexReturn, "1001");
            break;
        case 'a':
            strcpy(hexReturn, "1010");
            break;
        case 'b':
            strcpy(hexReturn, "1011");
            break;
        case 'c':
            strcpy(hexReturn, "1100");
            break;
        case 'd':
            strcpy(hexReturn, "1101");
            break;
        case 'e':
            strcpy(hexReturn, "1110");
            break;
        case 'f':
            strcpy(hexReturn, "1111");
            break;
        default:
            free(hexReturn);
            //hexReturn = NULL;
    }
    
    return hexReturn;
}

void joinString(char *binaryStr1, char *bitString1, int v) {
    int i = v;
    int j = 0;
    while (j < 4) {
        binaryStr1[i] = bitString1[j];
        i++;
        j++;
    }
}

char *hexToBinary(char *readline) {
    int v = 0;
    char *binaryStr = (char *)malloc(33 * sizeof(char));
    binaryStr[32] = '\0';
    char *bitString;
    
    for (int i = 0; i < 8; i++) {
        bitString = binaryConversion(readline[i]);
        if (bitString == NULL) {
            
            break;
        }
        joinString(binaryStr, bitString, v);
        v += 4;
        free(bitString);
    }
    
    return binaryStr;
}

int binaryToDecimal( char *binString, int size) {
   char a[size];
   for(int i = 0; i < size; i++){
      a[i] = binString[i];
   }

   
   int val = 0;
   for(int i = 0 ; i < size ;i++){
      if(a[i] == '1'){
         val = val + pow(2,  size - 1 - i);   
      }
   }
   return val;   

}

void memoryAccess(Cache* cache, char RW, char * binStr) {
    int blockOffsetBits = 0;
    int setIndexBits = 0;
    
    blockOffsetBits = log2(cache->blockSize);
    
    setIndexBits = log2(cache->numSets);
    
    char setIndexarray[setIndexBits + 1];
    
    char tagarr[32-(setIndexBits + blockOffsetBits) + 1];
    
    int y = 0;
    
    for (int i = 32 - (blockOffsetBits + setIndexBits); i < 32 - blockOffsetBits; i++)
    {
        /* code */
        setIndexarray[y] = binStr[i];
        y++;
    }
    setIndexarray[y] = '\0';
    y = 0;
    int setIndex = binaryToDecimal(setIndexarray, strlen(setIndexarray));
    for (int i = 0; i <= 32 - (setIndexBits + blockOffsetBits); i++)
    {
        /* code */
        tagarr[y] = binStr[i];
        y++;
    }
    tagarr[y] = '\0';
    y= 0;
    int hit = 0;
    for (int i = 0; i < cache->associativity; i++) {
        if (cache->sets[setIndex][i].valid /*cache->sets[setIndex][i].tag == tag*/  && strcmp(cache->sets[setIndex][i].tag, tagarr) == 0) {
            hit = 1;
            cacheHit++;
            
            if (strcmp(cache->replacePolicy, "LRU") == 0) {
                cache->sets[setIndex][i].lruCounter++;
            }

            break;
        }
    }

    
    if (hit == 0) {
        
        printf(" Miss, ");
        cacheMiss++;
        if(strcmp(cache->writePolicy, "WT") == 0 && RW =='W'){
            return;
        }
        
        int blockReplace = 0;
        if (strcmp(cache->replacePolicy, "FIFO") == 0) {
            blockReplace = 0;

        } else if (strcmp(cache->replacePolicy, "LRU") == 0) {
            
            for (int i = 1; i < cache->associativity; i++) {
                if (cache->sets[setIndex][i].lruCounter < cache->sets[setIndex][blockReplace].lruCounter) {
                    blockReplace = i;
                }
            }
        } else if (strcmp(cache->replacePolicy, "RANDOM") == 0) {
            
            blockReplace = rand() % cache->associativity;
        }

        
        if (cache->sets[setIndex][blockReplace].valid) {
            if (strcmp(cache->writePolicy, "WB") == 0) {
                //printf("Write back for replaceblock at set %d, index %d\n", setIndex, blockReplace);
            }
        }

        
        cache->sets[setIndex][blockReplace].valid = 1;
        //cache->sets[setIndex][replaceIndex].tag = tag;
        strcpy(cache->sets[setIndex][blockReplace].tag, tagarr);

        
        if (strcmp(cache->replacePolicy, "LRU") == 0) {
            cache->sets[setIndex][blockReplace].lruCounter = 0;
        }
    } else {
        //cacheHit++;
        printf(" Hit, ");
    }
}
char * hexStringReturn(char * line){
    char * hex = (char * )malloc(1024*sizeof(char));
    hex[1023]='\0';
    int y = 0;
    for (int  i = 0; i < 8 ; i++)
    {
        /* code */
        hex[y] = line[5+i];
        y++;
    }
    return hex;
}

void setIndexHexf(char * line){
    //char * setIndex = (char *)malloc(sizeof(char)* 1024);
    printf("set: 0x");
    for (int i = 0 ; i < 3; i++)
    {
        printf("%c", line[9+i]);
    }
    printf(" ");

}

void tagHexf(char * line){
    //char * setIndex = (char *)malloc(sizeof(char)* 1024);
    printf("tag: 0x");
    for (int i = 0 ; i < 6; i++)
    {
        printf("%c", line[5+i]);
    }
    printf(" ");

}
int main() {
    int totalSize;  
    printf("Enter total size of cache:\n");
    scanf("%d", &totalSize);
    int blockSize;     
    printf("Enter total size of block:\n");
    scanf("%d", &blockSize);
    int associativity;  
    printf("Enter total associativity:\n");
    scanf("%d", &associativity);

    char* replacePolicy = (char *)malloc(1024*sizeof(char));   
    printf("Enter replacement policy:\n");
    scanf("%s", replacePolicy);
    char* writePolicy = (char *)malloc(1024 *sizeof(char));       
    printf("Enter write policy:\n");
    scanf("%s", writePolicy);

    Cache* cache = initializeCache(totalSize, blockSize, associativity, replacePolicy, writePolicy);
    char * setIndexHex= (char *)malloc(1024 *sizeof(char));
    char * tagHex = (char *)malloc(1024 *sizeof(char));    
    FILE * file = fopen("trace2.txt", "r");
    char input[1024];
    char character;
    char * hexString = (char *)malloc(1024* sizeof(char));
    hexString[1023]='\0';
    char *binaryString;
    char readOrWrite;
    int cnt=0;
    while (fgets(input, sizeof(input), file) != NULL)
    {   
        cnt++;
        readOrWrite = input[0];
        hexString = hexStringReturn(input);
        printf("address:0x%s ", hexString);
        binaryString = hexToBinary(hexString);
        //printf(" %s,");
        //printf("binary string:%s\n", binaryString);
        setIndexHexf(input);
        memoryAccess(cache,readOrWrite, binaryString);
        tagHexf(input);
        printf("\n");

    }
    printf(" count :%d, cacheHit: %d, cacheMiss: %d\n",cnt, cacheHit, cacheMiss);
    
    return 0;
}








































