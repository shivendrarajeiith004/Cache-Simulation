Instructions to execute the following code for lab 6:

This code uses math.h library.
So, To compile the code use command:
    gcc main.c -lm 

Then code will ask for inputs for Cache size, cache block size, associativity,Replacement Policy and Writeback Policy.
inputs for Cache size, cache block size, associativity are of type integers, while for Replacement Policy inupts should either be "LRU" or "RANDOM" or "FIFO"
inputs for write back policy should be either "WB" or "WT". 

This codes support all parts of lab Assignment Question(including 1,2,3,4).