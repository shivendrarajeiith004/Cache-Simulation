

import java.io.*;


class CountAddress{
    public String filePath;
    private int counter = 0;
    
    public CountAddress(String filePath){
        this.filePath = filePath;
        
    
    }
    
    public int getCounter(){
        try(BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while((line = reader.readLine()) != null){
                //System.out.println(line);
                counter++;        
            }
        }catch(IOException e){
             System.err.println("Error reading the file: " + e.getMessage());        
            
        }
        //System.out.println("counter:" +counter);
        return counter;
    }
}

class HexToBinaryConverter {
    public int counter1;
    public String filePath1;
    public String [] HexToBinaryArray;
    
    public HexToBinaryConverter(int counter1, String filePath1){
        this.counter1 = counter1;
        this.filePath1 = filePath1;
        HexToBinaryArray = new String [counter1];
    }
    
    

    public void setHexToBinaryArray(){
        try(BufferedReader reader = new BufferedReader(new FileReader(filePath1))) {
            String line;
            int i = 0;
            while(((line = reader.readLine()) != null) && (i < counter1)){
                //System.out.println(line);
                
                String BinaryString  = hexToBinary(line);        
                
                //System.out.println(BinaryString);
                
                HexToBinaryArray[i] = BinaryString;
                
                //System.out.print(HexToBinaryArray[i]);
                
                i++;
            }
        }catch(IOException e){
            System.err.println("Error reading the file: " + e.getMessage());
            
        }
        
        
    }
    
    public String hexToBinary(String hexAddress) {
        
        hexAddress = hexAddress.replaceFirst("0x", "").replaceFirst("0X", "");

        
        long decimal = Long.parseLong(hexAddress, 16);

        
        String binary = Long.toBinaryString(decimal);

        
        int padding = 32 - binary.length();
        if (padding > 0) {
            StringBuilder paddedBinary = new StringBuilder();
            for (int i = 0; i < padding; i++) {
                paddedBinary.append("0");
            }
            paddedBinary.append(binary);
            binary = paddedBinary.toString();
            
            
        }
        
        return binary;
    }
    
    
    public String [] getHexToBinaryArray(){
        return HexToBinaryArray;
    }
    
}

class BinaryToSetIndex{
    public int counter2;
    public String[] HexToBinaryArray1;
    public int SetIndexBits;
    public int[] SetIndex;
     public String[] SetIndexString;
    public BinaryToSetIndex(String [] HexToBinaryArray1, int counter2,int SetIndexBits){
        this.counter2 = counter2;
        this.HexToBinaryArray1 = HexToBinaryArray1;
        this.SetIndexBits = SetIndexBits;
        SetIndex = new int[counter2];
        SetIndexString = new String[counter2];
    }
    
   
     
   
    
    public void setSetIndexString(){
        for(int i = 0; i < counter2;i++){
            SetIndexString[i] = HexToBinaryArray1[i].substring(25- SetIndexBits, 25);
        }
    }
    
    public void setSetIndex(){
        for(int i = 0; i < counter2;i++){
            SetIndex[i] = Integer.parseInt(SetIndexString[i], 2);
        }
    }
    
    public int[] getSetIndex(){
        return SetIndex;
    }
}    

class BinaryToTags{
    public int counter3;
    public String[] HexToBinaryArray2;
    public int SetIndexBits1;
    public String[] Tags;
    public BinaryToTags(int counter3, String[] HexToBinaryArray2, int SetIndexBits1){
        this.counter3 = counter3;
        this.HexToBinaryArray2 = HexToBinaryArray2;
        this.SetIndexBits1 = SetIndexBits1;
    	Tags = new String[counter3];
    }
    
  
    
  
    
    public void setTags(){
        for(int i =0; i <counter3;i++){
            Tags[i] = HexToBinaryArray2[i].substring(0, 25 - SetIndexBits1);
        }
    }
    
    public String[] getTags(){
        return Tags;
    }
}    

public class MyProject{
    public static void main(String [] args ){
        
         
        String filePath;
        int Associativity;
        
        
	    if (args.length == 0){
                System.out.println("No command-line parameters provided.");
        }
	    
	    else{
            //System.out.println("Command-line parameters:");
            
            for(int i = 0; i < args.length; i++)
		    {
                 //System.out.println("Parameter " + (i + 1) + ": " + args[i]);
            }
        }
            
            


	    
            int cacheSize = Integer.parseInt(args[0]);
        
            

	         Associativity = Integer.parseInt(args[1]);
            
	       
          
            
            int sets = (cacheSize*1024)/(Associativity*64);
            int ways = Associativity;
            double setValue = sets;
            double temp = Math.log(setValue)/Math.log(2);
	    filePath = args[2]; 	
            int setIndexBits = (int) temp;
            System.out.println("sets: "+sets+" ways: "+ways+" setIndexBits: "+setIndexBits);
	   
         
	        String [][]myArray1 = new String[sets][ways];
            
	        int [] CacheHit  =  new int[sets];
	        int [] CacheMiss =  new int[sets];
       	
	        //initializing values in arrays to zero
	
	        for(int i = 0; i < sets;i++){
	            CacheHit[i] = 0;
	            CacheMiss[i] = 0;
	        }
	        for(int i = 0; i < sets; i++){
	            for(int j = 0; j < ways; j++){
	       
	                myArray1[i][j] = "";	
	            }
	        }
        
        
        
        CountAddress obj = new CountAddress(args[2]);
        int totalAddress = obj.getCounter();
        
        HexToBinaryConverter obj1 = new HexToBinaryConverter(totalAddress, args[2]);
        obj1.setHexToBinaryArray();
        String [] MainHexToBinary = obj1.getHexToBinaryArray();
        
        BinaryToSetIndex obj2 = new BinaryToSetIndex(MainHexToBinary, totalAddress, setIndexBits);
        obj2.setSetIndexString();
        obj2.setSetIndex();
        int [] MainSetIndex = obj2.getSetIndex();
        
        BinaryToTags obj3 = new BinaryToTags(totalAddress, MainHexToBinary, setIndexBits);
        obj3.setTags();
        String [] MainTags = obj3.getTags();
        
        //logic code right here
                //logic for main code....
                

        
        
        
        for(int k = 0 ;k < totalAddress; k++){   
	        int counter4 = 0;	
	        
	        for(int i = 0; i < sets; i++){       
	            
	            if(MainSetIndex[k] == i){
		            
		            for(int j = 0; j < ways; j++){
		                
		                if(MainTags[k].equals(myArray1[i][j])){
		                    CacheHit[i]++;
		                    //cache swap code;

			   
			                for(int a = j; a < ways -1; a++){
			                    String temp2 = myArray1[i][a];
			                    myArray1[i][a] = myArray1[i][a+1];
			                    myArray1[i][a+1] = temp2;
			                    
			                }

		                    counter4 = 1;
		       		}
		       
		                if(!(MainTags[k].equals(myArray1[i][j])) &&j == ( ways-1)){
		            CacheMiss[i]++;
		            //cache miss code;
		            myArray1[i][0] = MainTags[k];
			        
			        for(int a = 0; a < ways - 1; a++ ){
			            String temp1 = myArray1[i][a];
			            myArray1[i][a] = myArray1[i][a+1];
			            myArray1[i][a+1] = temp1;
			   
			        }
		       }
		      
		   
		            }
		
		
		        }
	    
	    
	    
	    
	        }
	
	
	
	    } 
	 

        for(int i = 0 ; i < sets; i++){
	        if(CacheHit[i]!= 0 || CacheMiss[i] != 0)
	        System.out.println("in set: "+i+" number of cache hits: "+CacheHit[i]+" number of cache misses: "+CacheMiss[i]);
	
	
	    }
	    
	    int totalCacheHits = 0;
	    int totalCacheMisses = 0;

	    for(int i = 0; i < sets ;i++ ){ 
	        
	            totalCacheHits += CacheHit[i];
	            totalCacheMisses +=  CacheMiss[i];
	        
	
	    }
        
        System.out.println("total CacheHits: "+totalCacheHits+" total CacheMisses: "+totalCacheMisses);

    }
    }    
    
    

