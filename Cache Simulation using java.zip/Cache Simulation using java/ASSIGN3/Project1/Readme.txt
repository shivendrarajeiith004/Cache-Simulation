				SOFTWARE DEVELOPMENT FUNDAMENTALS
				    ASSIGNMENT NO.3
				GADEKAR SHIVENDRARAJE BABAN(CS22BTECH11022)    

1)This program simulate a set-associative cache memory and shows the following results after every run:
   1.Total misses. 
   2.Total hits.
   3.Set-wise total misses. 
   4.Set-wise total hits.

2)This program uses java to simulate a set-associative cache memory.

3)Input: 
	Through command line parameters are Cache size (P), Associativity (W),and the trace file path.
4)HOW DOES IT WORKS??
	1.This program uses a 2D -array of string to simulate the cache.
	
	2.To design the cache, the program first calculates the number of sets required and the set-index 		 					 
	
	3.configuration parameters, for Cache Size and Associativity. These parameters
         should be allowed to pass through command line parameters.
        
        4.this program is able to simulate cache of any size;
        
        5.This program Reads one address at a time from single line from the trace.then find out which 
         set it maps.
        
        6.Search that particular set in the cache for the block. 
        
        7.If tag matches, increments the hit counter. 
        
        8.Otherwise, increments the miss counter and place the newly requested block in the cache. 
	
	9.this program uses LRU as the replacement policy. 	
	
